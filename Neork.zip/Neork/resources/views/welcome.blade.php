<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Neork</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet">
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
</head>

<body>
    <div class="container mt-2">
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h2>Neork Technologies</h2>
                </div>
                <div class="pull-right mb-2">
                    <a class="btn btn-success" onClick="add()" href="javascript:void(0)"> Create Company</a>
                </div>
            </div>
        </div>
        @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
        @endif
        <div class="card-body" id="body">
            <table class="table table-bordered" id="ajax-crud-datatable">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Category</th>
                        <th>Hobby</th>
                        <th>Image</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
    <!-- boostrap company model -->
    <div class="modal fade" id="company-modal" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="CompanyModal"></h4>
                    <button type="button" class="close closed" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="javascript:void(0)" id="CompanyForm" name="CompanyForm" class="form-horizontal"
                        method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="id" id="id">
                        <div class="form-group">
                            <label for="name" class="col-sm-2 control-label">Name</label>
                            <div class="col-sm-12">
                                <input type="text" class="form-control" id="name" name="name"
                                    placeholder="Enter Name" maxlength="50" required="">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="name" class="col-sm-2 control-label">Contact No</label>
                            <div class="col-sm-12">
                                <input type="number" class="form-control" id="number" name="number"
                                    placeholder="Enter Number" maxlength="50" required="">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">Hobby</label>
                            <div class="col-sm-12" id="HobbyBody">
                               
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">Category</label>
                            <div class="col-sm-12" id="">
                                <select class="form-control" name="Category" id="Category" required="">
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                                <label for="formFile" class="form-label">Profile Pic</label>
                            <div class="col-sm-12" id="">
                                <input class="form-control" type="file" id="formFile" name="formFile" required="">
                            </div>
                        </div>
                        <div class="col-sm-offset-2 col-sm-10">
                            <button type="submit" class="btn btn-primary" id="btn-save">Save changes
                            </button>
                            <button type="button" class="btn btn-secondary closed" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                </div>
            </div>
        </div>
    </div>
    <!-- end bootstrap model -->
</body>
<script type="text/javascript">
$(document).ready(function() {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    
    $('.closed').click(function(e) {
        e.preventDefault();
        $('#body').show();
    });
    var html = "";
    $('#ajax-crud-datatable').DataTable({
        processing: true,
        serverSide: true,
        ajax: "{{ url('ajax-crud-datatable') }}",
        columns: [
            {
                data: 'name',
                name: 'name'
            },
            {
                data: 'phone',
                name: 'phone'
            },
            {
                data: 'catName',
                name: 'catName'
            },
            {
                data: "HobbyIds",
                render: function(data, type, row) {
                    var html = "";
                    console.log(data);
                    if(data){
                        var datas = data.split(',');
                        $.each(datas , function (i, value) {
                                                
                        if(value ==1) {
                                    
                            html +=" Programming ";
                                
                            }else if (value ==2) {

                                html +=" Games";
                                    
                            }else if(value == 3){
                                html +=" Reading";
                            }
                        });
                        return html;
                    }
                   
                }
            },
            {
                data: 'image',
                render: function (data, type, row, meta) {
                    console.log(data);
                    return '<img src="uploads/' + data + '" alt="' + data + '"height="50" width="50"/>';
                }
            },
            {
                data: 'action',
                name: 'action',
                orderable: false
            },
        ],
        order: [
            [0, 'desc']
        ]
    });
});

function add() {
    
    $.ajax({
        type: "get",
        url: "{{ url('add-personal') }}",
        dataType: 'json',
        success: function(res) {
            //console.log(res.cat);
            $('#CompanyForm').trigger("reset");
            $('#body').hide();
            $('#CompanyModal').html("Add");
            $('#company-modal').modal({backdrop:'static',keyboard:false, show:true});
            $('#body').hide();
            $("#HobbyBody").empty();
            $("#Category").empty('');
            //$('#company-modal').modal('show');
            var trHTML = '';
            $.each(res.hobby, function (i, value) {
                //console.log(value.name);
                trHTML +=  "<div class='form-check'>"+
                                "<input class='form-check-input' type='checkbox' name='flexCheckDefault[]' value='"+value.id+"' id='flexCheckDefault"+value.id+"'>"+
                                "<label class='form-check-label' for='flexCheckDefault"+value.id+"'>"+value.name+"</label>"+
                            "</div>";
            });
            $("#HobbyBody").html(trHTML);
            var selectHtml = '';
            $.each(res.cat, function (i, value) {
                $('#Category')
                    .append($("<option></option>")
                                .attr("value", value.id)
                                .text(value.name)); 
            });
            //console.log(selectHtml);
        }
    });
}

function editFunc(id) {
    $.ajax({
        type: "POST",
        url: "{{ url('edit-company') }}",
        data: {
            id: id
        },
        dataType: 'json',
        success: function(res) {
            console.log(res);
            $('#CompanyModal').html("Edit");
            $('#company-modal').modal({backdrop:'static',keyboard:false, show:true});
            $('#body').hide();
            //$('#company-modal').modal('show');
            $('#id').val(res.company[0].id);
            $('#name').val(res.company[0].name);
            $('#number').val(res.company[0].phone);
            $("#HobbyBody").empty();
            $("#Category").empty('');
            var trHTML = '';
            $.each(res.hobby, function (i, value) {
                //console.log(value.name);
                var datas = res.company[0].HobbyIds.split(',');
                var array = JSON.parse("[" + datas + "]");
                //console.log(array);
                if(jQuery.inArray(value.id, array) != -1){
                    trHTML +=  "<div class='form-check'>"+
                                "<input class='form-check-input' type='checkbox' name='flexCheckDefault[]' value='"+value.id+"' id='flexCheckDefault"+value.id+"' checked> "+
                                "<label class='form-check-label' for='flexCheckDefault"+value.id+"'>"+value.name+"</label>"+
                            "</div>";
                }else{
                    trHTML +=  "<div class='form-check'>"+
                                "<input class='form-check-input' type='checkbox' name='flexCheckDefault[]' value='"+value.id+"' id='flexCheckDefault"+value.id+"' > "+
                                "<label class='form-check-label' for='flexCheckDefault"+value.id+"'>"+value.name+"</label>"+
                            "</div>";
                }
            });
            $("#HobbyBody").html(trHTML);
            var selectHtml = '';
            $.each(res.category, function (i, value) {
               
                $('#Category')
                    .append($("<option></option>")
                                .attr("value", value.id)
                                .text(value.name)); 
            });
            $('select option[text="Designer"]').prop('selected', true);

           // $('#Category').val(res.company[0].Category);
        }
    });
}

function deleteFunc(id) {
    if (confirm("Delete Record?") == true) {
        var id = id;
        // ajax
        $.ajax({
            type: "POST",
            url: "{{ url('delete-company') }}",
            data: {
                id: id
            },
            dataType: 'json',
            success: function(res) {
                var oTable = $('#ajax-crud-datatable').dataTable();
                oTable.fnDraw(false);
            }
        });
    }
}
$('#CompanyForm').submit(function(e) {
    e.preventDefault();
    var formData = new FormData(this);
    //console.log(formData);
    $.ajax({
        type: 'POST',
        url: "{{ url('store-company')}}",
        data: formData,
        cache: false,
        contentType: false,
        processData: false,
        success: (data) => {
            $("#company-modal").modal('hide');
            var oTable = $('#ajax-crud-datatable').dataTable();
            oTable.fnDraw(false);
            $("#btn-save").html('Submit');

            $("#btn-save").attr("disabled", false);
            $('#body').show();
        },
        error: function(data) {
            //console.log(data);
        }
    });
});
</script>

</html>