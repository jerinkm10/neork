<?php


namespace App\Http\Controllers;
 
use Illuminate\Http\Request;
 
use App\Models\Company;

use DB;
 
use Datatables;
 
class DataTableAjaxCRUDController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(request()->ajax()) {
            //$category =  Company::select('*');
            $category =  DB::table('companies')
            ->leftjoin('category as cat', 'cat.id', '=', 'companies.cat')
            ->leftjoin('perosnalhobby', 'perosnalhobby.perosnalId', '=', 'companies.id'  )
            ->select('companies.id','companies.name as name','companies.phone','cat.name as catName','companies.image',DB::raw('group_concat(`perosnalhobby`.`HobbyId`) as HobbyIds'))
            ->groupBy('companies.id','companies.name','companies.phone','cat.name','companies.image')
            ->get();
            //dd($category);
            return datatables()->of($category)
            ->addColumn('action', 'company-action')
            ->rawColumns(['action'])
            ->addIndexColumn()
            ->make(true);
        }
        return view('companies');
    }
    public function addPersonal(){
        if(request()->ajax()) {
            //$where = array('id' => $request->id);
            $category  =  DB::table('category')->get();
            $hobby  =  DB::table('hobby')->get();
          
            return Response()->json(['cat'=>$category,'hobby'=>$hobby]);
        }
    }
      
      
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {  
        $name = time().'.'.request()->formFile->getClientOriginalExtension();
  
        $request->formFile->move(public_path('uploads'), $name);
        $companyId = $request->id;
        if(!empty($companyId)){
                $company   =   DB::table('companies')->where('companies.id',$companyId)->update(
                    [
                        'name' => $request->name, 
                        'phone' => $request->number,
                        'cat' => $request->Category,
                        'image' => $name,
                    ]); 
                    $perosnalhobby = DB::table('perosnalhobby')->where('perosnalId',$companyId)->delete();
                foreach($request->flexCheckDefault as $value){
                    DB::table('perosnalhobby')->insert(
                        [   
                            'HobbyId'	    => $value,
                            'perosnalId'	=> $companyId,
                            'status'	    => 1,
                          
                   ]);
                }
        }else{
            $company   =   DB::table('companies')->insertGetId(
                [
                'name' => $request->name, 
                'phone' => $request->number,
                'cat' => $request->Category,
                'image' => $name,
                ]); 
                foreach($request->flexCheckDefault as $value){
                    DB::table('perosnalhobby')->insert(
                        [   
                            'HobbyId'	    => $value,
                            'perosnalId'	=> $company,
                            'status'	    => 1,
                          
                   ]);
                }
        }
       
                   
                         
        return Response()->json($request);
 
    }
      
      
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\company  $company
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {   
        $where = array('companies.id' => $request->id);
        $company =  DB::table('companies')
        ->join('category as cat', 'cat.id', '=', 'companies.cat')
        ->leftjoin('perosnalhobby', 'perosnalhobby.perosnalId', '=', 'companies.id'  )
        ->where($where)
        ->select('companies.id','companies.name as name','companies.phone','cat.name as catName','companies.image',DB::raw('group_concat(`perosnalhobby`.`HobbyId`) as HobbyIds'))
        ->groupBy('companies.id','companies.name','companies.phone','cat.name','companies.image')
        ->get();
        $category  =  DB::table('category')->get();
        $hobby  =  DB::table('hobby')->get();
       // $company  = Company::where($where)->first();
      
        return Response()->json(['company'=>$company,'category'=> $category,'hobby'=>$hobby]);
    }
      
      
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\company  $company
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $company = Company::where('id',$request->id)->delete();
      
        return Response()->json($company);
    }
}
